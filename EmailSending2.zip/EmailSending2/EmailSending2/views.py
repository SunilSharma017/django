from django.http import HttpResponse
from django.shortcuts import render,redirect
from emailsender.models import employeData
from django.core.mail import send_mail
def Index(request):
    if request.method=="POST":
        name=request.POST.get("n1")
        email=request.POST.get("n2")
        password=request.POST.get("n3")

        employeData.objects.create(name=name,email=email,password=password)
        send_mail(
            subject="django email testing ",
            message=f""" Hi {name} 
            you have successfully login in my website . we are sending this mail 
             regarding to test django mail system . Thanks for login in my website


            Your Regards 
            Sunil Sharma

            your detail is  : 
            name : {name},
            email : {email},
            password:{password}

                """,
            from_email="sharmasunil7742@gmail.com",
            recipient_list=["mohitsharma.s7576@gmail.com","mukulbhatia685@gmail.com","deepydv812@gmail.com","vishalkhola2003@gmail.com",email]
        )

    return render(request,"index.html")

# send mail : 
# subject 
# message 
# from_email 
# recipient_list=[]


# django api 
# authentication 
# adminstration 
# filters . 