from django.apps import AppConfig


class TcaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TCAAPP'
