from django.http import HttpResponse
from django.shortcuts import render,redirect
from emailApp.models import EmailStudent
from django.core.mail import send_mail
from django.conf import settings

def Home(request):
    if request.method=="POST":
        name=request.POST.get("n1")
        email=request.POST.get("n2")
        password=request.POST.get("n3")
        phoneNumber=int(request.POST.get("n4"))
        EmailStudent.objects.create(name=name,email=email,password=password,phoneNumber=phoneNumber)
        send_mail(
            subject="verification",
            message=f"Hey! {name} welcome in my website  . Your mail has been verified .  ",
            from_email="sharmasunil7742@gmail.com",
            recipient_list=[email]
        )

    return render(request,"index.html")


# smtp : protocol . 
# end to end protocol . 

# send_mail(subject,message,from_email,recipient_list)