from django.apps import AppConfig


class SuntechConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'suntech'
