from django.http import HttpResponse
from django.shortcuts import render,redirect
from suntech.models import Person

def Home(request):
    if request.method=="POST":
        name=request.POST.get("n1")
        email=request.POST.get("n2")
        password=request.POST.get("n3")
        resume=request.FILES.get("n4")
        Person.objects.create(name=name,email=email,password=password,resume=resume)
    return render(request,"index.html")