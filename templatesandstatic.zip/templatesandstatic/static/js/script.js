let body=document.querySelector("body")
let count=0

function jaduiFunction(){
if(count%2===0){
    body.style.backgroundColor="red"
    count++
}
else{
    body.style.backgroundColor="black"
    count++
}
}
